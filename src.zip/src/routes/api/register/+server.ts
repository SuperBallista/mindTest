import type { RequestHandler } from '@sveltejs/kit';
import { User } from '$lib/entities/User';
import bcrypt from 'bcryptjs';
import { AppDataSource } from '$lib/ormconfig';

export const POST: RequestHandler = async ({ request }) => {
  try {
    const { email, nickname, password } = await request.json();

    if (!email || !nickname || !password) {
      return new Response(JSON.stringify({ success: false, message: '모든 필드를 입력하세요.' }), { status: 400 });
    }

    // ✅ 닉네임 유효성 검사
    const nicknameRegex = /^[ㄱ-ㅎ가-힣a-zA-Z0-9]+$/;
    if (!nicknameRegex.test(nickname) || nickname.length < 2 || nickname.length > 20) {
      return new Response(JSON.stringify({ success: false, message: '닉네임은 한글, 영어, 숫자로만 구성되며 2~20자여야 합니다.' }), { status: 400 });
    }

    // ✅ 닉네임 및 이메일 중복 확인
    const userDB = AppDataSource.getRepository(User);
    const existingUser = await userDB.findOne({ where: [{ username: nickname }] });

    if (existingUser) {
      return new Response(JSON.stringify({ success: false, message: '이미 사용 중인 이메일 또는 닉네임입니다.' }), { status: 400 });
    }

    // ✅ 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(password, 12);

    // ✅ 새 사용자 생성
    const newUser = userDB.create({
      email: email,
      username: nickname,
      password: hashedPassword,
      origin: "local"
    });
    await userDB.save(newUser);

    return new Response(JSON.stringify({ success: true, message: '회원가입 성공!' }), { status: 201 });
  } catch (error) {
    console.error('회원가입 오류:', error);
    return new Response(JSON.stringify({ success: false, message: '서버 오류가 발생했습니다.' }), { status: 500 });
  }
};
