import { json } from '@sveltejs/kit';
import type { RequestHandler } from '@sveltejs/kit';
import { AppDataSource } from '$lib/ormconfig';
import { Post } from '$lib/entities/Post';
import { Result } from '$lib/entities/Result';
import { TempUpload } from '$lib/entities/TempUpload';
import { User } from '$lib/entities/User';
import { v4 as uuid } from 'uuid'; // ✅ 정상 작동
import type { TestData } from '$lib/stores/testStore';

export const POST: RequestHandler = async ({ request, locals }) => {
    const queryRunner = AppDataSource.createQueryRunner();
    await queryRunner.startTransaction(); // 트랜잭션 시작

    try {
        // ✅ 1. 클라이언트에서 받은 데이터 가져오기
        const requestData:TestData = await request.json();
        const { category, title, description, image, results, resultType, questions } = requestData;


        // ✅ 결과에 UUID 할당
        results.forEach(result => {
            result.resultDBId = uuid();
        });
        
        // ✅ questions 내부 choices에 resultDBId 매핑
        questions.forEach(question => {
            question.choices.forEach(choice => {
                if (choice.resultId !== null && requestData.results[choice.resultId]) {
                    choice.resultDBId = requestData.results[choice.resultId].id;
                }
            });
        });

                
        console.log(requestData);
        
        const postRepository = queryRunner.manager.getRepository(Post);
        const resultRepository = queryRunner.manager.getRepository(Result);
        const tempUploadRepository = queryRunner.manager.getRepository(TempUpload);
        const userRepository = queryRunner.manager.getRepository(User);

        // ✅ 2. 사용자 조회 (FK 관계 반영)
        const user = await userRepository.findOneBy({ id: locals.user.id });
        if (!user) {
            throw new Error("유효하지 않은 사용자입니다.");
        }

        // ✅ 3. 게시글 저장 (FK → `user` 필드 사용)
        const newPost = postRepository.create({
            user, // ✅ `userId` 대신 `user` 객체 사용
            category,
            title,
            description,
            image,
            content: requestData,
            created_at: new Date(),
            updated_at: new Date(),
        });
        const savedPost = await queryRunner.manager.save(newPost); // 게시글 저장

        // ✅ 4. 결과 저장 (연결된 결과 데이터 저장)
        for (const result of results) {
            if (!result.resultDBId) {
                throw new Error(`Result ID가 존재하지 않습니다: ${JSON.stringify(result)}`);
            }
        
            const newResult = resultRepository.create({
                post: savedPost,
                description: result.description,
                image: result.image,
                type: resultType,
                title: result.title,
                id: result.resultDBId, // 여기서는 이미 null 가능성 제거됨
            });
        
            await queryRunner.manager.save(newResult);
        }
        
        // ✅ 5. 임시 업로드된 이미지 정리 (FK → `temp_post` 관계 반영)
        if (image) {
            await tempUploadRepository
                .createQueryBuilder()
                .delete()
                .where("file_path = :image", { image })
                .execute();
        }

        await queryRunner.commitTransaction(); // 트랜잭션 커밋
        return json({ message: '게시글이 성공적으로 업로드되었습니다.', postId: savedPost.id });

    } catch (error) {
        console.error("❌ 게시글 업로드 중 오류 발생:", error);
        await queryRunner.rollbackTransaction(); // 트랜잭션 롤백
        return json({ error: '서버 오류 발생' }, { status: 500 });
    } finally {
        await queryRunner.release(); // 트랜잭션 종료
    }
};
