import type { RequestHandler } from '@sveltejs/kit';
import { AppDataSource } from '$lib/ormconfig';
import { Category } from '$lib/entities/Category';


export const GET: RequestHandler = async () => {
  try {
    const categoryRepo = AppDataSource.getRepository(Category);
    const categories = await categoryRepo.find(); // ✅ 모든 카테고리 조회

    return new Response(JSON.stringify(categories), { status: 200 });
  } catch (error) {
    console.error('카테고리 조회 실패:', error);
    return new Response(JSON.stringify({ success: false, message: '서버 오류 발생' }), { status: 500 });
  }
};
