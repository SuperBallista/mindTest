<script lang="ts">
    export let test: {
      id: string;
      title: string;
      description?: string;
      image?: string;
    };

    function markAsRead(testId: string) {
  let readTests = JSON.parse(sessionStorage.getItem('readTests') || '[]');
  if (!readTests.includes(testId)) {
    readTests.push(testId);
    sessionStorage.setItem('readTests', JSON.stringify(readTests));
  }
}


  </script>
  
  <article class="bg-white shadow-md rounded-lg overflow-hidden transform transition hover:scale-105">
    <img src={test.image || "/images/basic.jpg"} alt={test.title} class="w-full h-48 object-cover" />
    <div class="p-4">
      <h2 class="text-xl font-semibold mb-2">{test.title}</h2>
      <p class="text-gray-600 mb-4">{test.description}</p>
      <a href={`/test/${test.id}`} class="text-blue-500 hover:underline font-medium" on:click={() => markAsRead(test.id)}>
        테스트 보러 가기 →
      </a>
    </div>
  </article>
  