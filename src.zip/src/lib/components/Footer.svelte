<footer class="bg-gray-800 text-gray-300 text-sm py-4">
    <div class="container mx-auto text-center">
      <p>&copy; 2025 땅콩 | All rights reserved.</p>
      <nav class="mt-2">
        <ul class="flex justify-center space-x-4">
          <li>
            <a href="/terms" class="hover:underline">이용약관</a>
          </li>
          <li>
            <a href="/privacy" class="hover:underline">개인정보처리방침</a>
          </li>
        </ul>
      </nav>
    </div>
  </footer>
  