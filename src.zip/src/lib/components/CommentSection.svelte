<script lang="ts">
    import { onMount } from 'svelte';
    import { writable } from 'svelte/store';

    export let testId: string;
    let comment = "";
    let comments = writable<{ user: string; text: string }[]>([]);

    function addComment() {
        if (comment.trim() === "") return;
        comments.update((prev) => [...prev, { user: "익명", text: comment }]);
        comment = "";
    }

    onMount(async () => {
        console.log(`📩 댓글 데이터 로드 - 테스트 ID: ${testId}`);
        // ✅ 서버에서 해당 테스트의 댓글 불러오기 로직 추가
    });
</script>

<div class="bg-gray-100 p-4 rounded-lg mt-4 border border-gray-300">
    <h2 class="text-lg font-semibold text-gray-800 mb-3">💬 댓글</h2>

    <!-- ✅ 댓글 입력: 모바일 대응 -->
    <div class="flex flex-wrap items-center space-x-2 mb-4">
        <input 
            type="text" 
            bind:value={comment} 
            placeholder="댓글을 입력하세요..."
            class="flex-1 min-w-0 px-4 py-2 border border-gray-400 rounded-lg focus:ring focus:ring-blue-200" 
        />
        <button 
            class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition shrink-0">
            등록
        </button>
    </div>

    <!-- ✅ 댓글 리스트 -->
    <div class="space-y-2">
        {#each $comments as c}
            <div class="p-3 bg-white border border-gray-300 rounded-lg shadow">
                <strong class="text-gray-800">{c.user}</strong>
                <p class="text-gray-700">{c.text}</p>
            </div>
        {/each}
    </div>
</div>
