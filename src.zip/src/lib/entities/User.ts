import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid') // ✅ UUID 자동 생성
  id: string;

    @Column({ type: 'varchar', length: 255, unique: true })
    username: string;


    @Column({ type: 'varchar', length: 255, unique: true })
    email: string;

    @Column({ type: 'varchar', length: 255, nullable: true })
    password?: string; // 직접 가입자를 위한 암호 (Google OAuth는 NULL)

    @Column({ type: 'enum', enum: ['google', 'local'] })
    origin: 'google' | 'local'; // 로그인 방식

    @CreateDateColumn({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    created_at: Date;
}
